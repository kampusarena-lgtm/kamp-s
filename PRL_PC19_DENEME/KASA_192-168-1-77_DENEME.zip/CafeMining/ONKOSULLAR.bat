@echo off
setlocal
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo Python 3.11 veya daha yeni surum ve py baslaticisi gerekiyor.
  echo Resmi Windows kurulumu: https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
py -3 -m pip install --user -r "%~dp0requirements.txt"
set "SETUP_RESULT=%errorlevel%"
if not "%SETUP_RESULT%"=="0" echo On kosul kurulumu tamamlanamadi. Yukaridaki hatayi kontrol et.
pause
exit /b %SETUP_RESULT%
