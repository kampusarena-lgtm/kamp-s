@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
if exist "panel_private\server.json" (
  echo Kasa ayarlari zaten var. Mevcut anahtarlar korundu.
  popd
  pause
  exit /b 0
)
py -3 setup_panel.py --url http://192.168.1.77:8790 --listen 192.168.1.77
set "SETUP_RESULT=%errorlevel%"
if "%SETUP_RESULT%"=="0" (
  echo Anahtarlar yalnizca bu kasada olusturuldu.
  echo PC19 icin panel_private\agent_settings\PC19-BUSINESS.json dosyasini kullan.
)
popd
pause
exit /b %SETUP_RESULT%
