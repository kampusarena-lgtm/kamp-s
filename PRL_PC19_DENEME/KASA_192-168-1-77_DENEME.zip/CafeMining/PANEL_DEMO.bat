@echo off
cd /d "%~dp0"
py -3 control_panel.py --demo
pause
