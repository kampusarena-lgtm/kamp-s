@echo off
"%~dp0Panel.exe" --demo
