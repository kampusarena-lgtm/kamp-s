"""Read-only image matching diagnostics. Never starts mining or sends OS commands."""
import argparse
import json
from pathlib import Path
import socket
import time

from vision import VisionReader, compare_images
from windows_runtime import Windows

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worker', default=socket.gethostname().upper())
    parser.add_argument('--image', type=Path, help='Compare an existing screenshot file instead of the desktop')
    parser.add_argument('--watch', action='store_true')
    args = parser.parse_args()
    reader = VisionReader(ROOT, args.worker)
    if args.image:
        from PIL import Image
        with Image.open(args.image) as frame:
            result = compare_images(frame, reader.reference, reader.calibration)
        result['diagnostic_only'] = True
        result['mining_started'] = False
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    api = Windows()
    try:
        while True:
            reader.read(api)
            print(json.dumps(reader.last_report, ensure_ascii=False))
            if not args.watch:
                break
            time.sleep(2)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
