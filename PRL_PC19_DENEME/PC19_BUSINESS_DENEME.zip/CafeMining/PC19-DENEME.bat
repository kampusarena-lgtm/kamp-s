@echo off
setlocal
if /i not "%COMPUTERNAME%"=="PC19-BUSINESS" (
  echo Bu deneme yalnizca PC19-BUSINESS icindir. Mevcut cihaz: %COMPUTERNAME%
  pause
  exit /b 1
)
pushd "%~dp0"
if errorlevel 1 exit /b 1
echo PC19 kurulum denemesi - mining ve OC komutu verilmez.
echo 1 Bos kilit ekrani
echo 2 Musteri masaustu
echo 3 Oyun ekrani
echo 4 Siyah ekran
choice /c 1234 /n /m "Deneme turunu sec: "
if errorlevel 255 goto cancelled
if errorlevel 4 goto black
if errorlevel 3 goto game
if errorlevel 2 goto customer
if errorlevel 1 goto empty
goto cancelled
:black
set "TRIAL_LABEL=siyah"
goto run
:game
set "TRIAL_LABEL=oyun"
goto run
:customer
set "TRIAL_LABEL=musteri"
goto run
:empty
set "TRIAL_LABEL=bos"
:run
py -3 commission.py --settings "%~dp0device-settings\PC19-BUSINESS.json" --label "%TRIAL_LABEL%"
set "TRIAL_RESULT=%errorlevel%"
popd
pause
exit /b %TRIAL_RESULT%
:cancelled
popd
exit /b 1
